package com.example.hmmarket.launchscreen

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.CountDownTimer
import com.example.hmmarket.R
import com.example.hmmarket.authscreen.AuthActivity
import com.example.hmmarket.catalogscreen.CatalogActivity

class LaunchActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_launch)

        supportActionBar?.hide()

        object : CountDownTimer(3000,1000) {
            override fun onTick(millisUntilFinished: Long) {
                // заставляем пялиться на нашу заставку как минимум 3 секунды
            }

            override fun onFinish() {
                switchToSecond()
            }
        }.start()
    }
    fun switchToSecond(){

        val myPreferences = getSharedPreferences("settings", MODE_PRIVATE)
        val isFirstEnter = myPreferences.getBoolean("isFirstEnter", true)

        val editor = myPreferences.edit()
        try {
            editor.putBoolean("isFirstEnter", false )
        }finally {
            editor.commit()
        }

        runOnUiThread {
            if (isFirstEnter)
                startActivity(Intent(this, AuthActivity::class.java))
            else
                startActivity(Intent(this, AuthActivity::class.java))
        }
    }
}