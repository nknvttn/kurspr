package com.example.hmmarket.registrscreen

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import com.example.hmmarket.R
import com.example.hmmarket.authscreen.AuthActivity
import com.example.hmmarket.catalogscreen.CatalogActivity

class RegistrActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_registr)
    }

    fun AuthEnterClick(view: View) {
        startActivity(
            Intent(this, AuthActivity::class.java)
        )
    }
}