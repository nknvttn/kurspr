﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Rukodelie.Models
{
    public partial class Kpkarty
    {
        public int Id { get; set; }
        public int KlientId { get; set; }
        public string Vladelets { get; set; }
        public string NomerKarty { get; set; }
        public string SrokDeistviya { get; set; }

        public virtual Kpklient Klient { get; set; }
    }
}
