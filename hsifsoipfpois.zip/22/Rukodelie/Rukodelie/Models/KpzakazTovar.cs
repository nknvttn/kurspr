﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Rukodelie.Models
{
    public partial class KpzakazTovar
    {
        public int Id { get; set; }
        public int ZakazId { get; set; }
        public int TovarId { get; set; }
        public int Kolichestvo { get; set; }
        public float Stoimost { get; set; }

        public virtual Kptovar Tovar { get; set; }
        public virtual Kpzakaz Zakaz { get; set; }
    }
}
