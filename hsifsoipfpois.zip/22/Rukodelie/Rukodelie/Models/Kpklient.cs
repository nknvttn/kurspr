﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Rukodelie.Models
{
    public partial class Kpklient
    {
        public Kpklient()
        {
            Kpkarties = new HashSet<Kpkarty>();
            Kpzakazs = new HashSet<Kpzakaz>();
        }

        public int Id { get; set; }
        public string Imya { get; set; }
        public string Familiya { get; set; }
        public string Otchestvo { get; set; }
        public string Login { get; set; }
        public DateTime? DenRozhdeniya { get; set; }
        public string PassWord { get; set; }

        public virtual ICollection<Kpkarty> Kpkarties { get; set; }
        public virtual ICollection<Kpzakaz> Kpzakazs { get; set; }
    }
}
