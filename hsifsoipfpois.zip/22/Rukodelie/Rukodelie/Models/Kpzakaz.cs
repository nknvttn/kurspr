﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Rukodelie.Models
{
    public partial class Kpzakaz
    {
        public Kpzakaz()
        {
            KpzakazTovars = new HashSet<KpzakazTovar>();
        }

        public int Id { get; set; }
        public int KlientId { get; set; }
        public int StatusId { get; set; }
        public DateTime DataZakaza { get; set; }
        public string AdresKlient { get; set; }
        public DateTime DataDostavki { get; set; }
        public DateTime DataOplaty { get; set; }

        public virtual Kpklient Klient { get; set; }
        public virtual Kpstatus Status { get; set; }
        public virtual ICollection<KpzakazTovar> KpzakazTovars { get; set; }
    }
}
