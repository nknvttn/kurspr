﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Rukodelie.Models
{
    public partial class Kpstatus
    {
        public Kpstatus()
        {
            Kpzakazs = new HashSet<Kpzakaz>();
        }

        public int Id { get; set; }
        public string Status { get; set; }

        public virtual ICollection<Kpzakaz> Kpzakazs { get; set; }
    }
}
