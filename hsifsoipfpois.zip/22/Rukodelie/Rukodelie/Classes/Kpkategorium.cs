﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Rukodelie.Models
{
    public partial class Kpkategorium
    {
        public override string ToString()
        {
            return Nazvanie;
        }
        public override bool Equals(object obj)
        {
            return (obj != null) &&
                (obj is Kpkategorium) &&
                (this.Id == (obj as Kpkategorium).Id);

        }
    }
}
