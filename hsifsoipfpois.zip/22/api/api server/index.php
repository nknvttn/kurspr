<?php

class ApiServer
{
    private $db = null;

    public function __construct(){
        // результат в формате JSON
        header('Content-Type: application/json; utf-8');

        try {

            if(!isset($_SERVER['PATH_INFO']))
             throw new Exception(print_r($_SERVER));
             
            switch($_SERVER['REQUEST_METHOD'])
            {
                case 'GET': 
                    $this->processGet($_SERVER['PATH_INFO']);
                    break;
                case 'POST':
                    $this->processPost($_SERVER['PATH_INFO']);
                    break;
            }
        } catch (\Throwable $th) {
            header("HTTP/1.1 500 Server error");
            $response['error'] = $th->getMessage();
            // выводим в stdout JSON-строку
            echo json_encode($response, JSON_UNESCAPED_UNICODE);
        }
    }

    private function processPost($path){
        switch($path)
        {
            case '/login':
                $params = json_decode(file_get_contents('php://input'));
                $this->connect();
                $query = $this->db
                    ->prepare("SELECT * FROM KPKlient WHERE login=:login");
                $query->bindValue(':login', $params->login);
                $query->execute();
                $response =  $query->fetch(PDO::FETCH_ASSOC);
                if ($response){
                    if($response['passWord'] == $params->password){
                        echo json_encode([
                            'imya'=> $response['imya']
                        ], JSON_UNESCAPED_UNICODE);

                    } else{
                        header("HTTP/1.1 403 Bad password");
                    }
                } else{
                    header("HTTP/1.1 404 User not found");
                }
                break;


        }
    }

    private function processGet($path)
    {
        switch($path)
        {
            case '/Tovar':
                $this->connect();
                // $this->auth();
                
                // получаем данные
                $response = $this->db
                    ->query("SELECT * FROM KPTovar")
                    ->fetchAll(PDO::FETCH_ASSOC);
                echo json_encode($response, JSON_UNESCAPED_UNICODE);
                break;

                case '/Zakaz':
                    $this->connect();
                    $user=$this->auth();
                    $query = $this->db->prepare("SELECT * FROM KPZakaz WHERE klientId=:id");
                    $query->bindValue(':id', $user["id"]);
                    $query->execute();
                    $resp = $query->fetchAll(PDO::FETCH_ASSOC);
                        echo json_encode($resp, JSON_UNESCAPED_UNICODE);
                    break;

                case '/Kategoria':
                    $this->connect();
                    // $this->auth();
                    // получаем данные
                    $response = $this->db
                        ->query("SELECT * FROM KPKategoria")
                        ->fetchAll(PDO::FETCH_ASSOC);
                    echo json_encode($response, JSON_UNESCAPED_UNICODE);
                    break;

                case '/ZakazTovar':
                    $this->connect();
                    $user = $this->auth();
                    $query = $this->db->prepare("SELECT * FROM KPZakazTovar WHERE klientId=:id");
                    $query->bindValue(':id', $user["id"]);
                    $query->execute();
                    $resp = $query->fetchAll(PDO::FETCH_ASSOC);
                        echo json_encode($resp, JSON_UNESCAPED_UNICODE);
                    break;
                
                case '/Klient':
                    $this->connect();
                    $user=$this->auth();
                    $query = $this->db->prepare("SELECT imya, familiya, otchestvo, denRozhdeniya FROM KPKlient WHERE id=:id");
                    $query->bindValue(':id', $user["id"]);
                    $query->execute();
                    $resp = $query->fetchAll(PDO::FETCH_ASSOC);
                        echo json_encode($resp, JSON_UNESCAPED_UNICODE);
                    break;
                
                case '/Karty':
                    $this->connect();
                    $user=$this->auth();
                    $query = $this->db->prepare("SELECT * FROM KPKarty WHERE klientId=:id");
                    $query->bindValue(':id', $user["id"]);
                    $query->execute();
                    $resp = $query->fetchAll(PDO::FETCH_ASSOC);
                        echo json_encode($resp, JSON_UNESCAPED_UNICODE);
                    break;

                case '/Status':
                    $this->connect();
                    // $this->auth();
                    // получаем данные
                    $response = $this->db
                        ->query("SELECT * FROM KPStatus")
                        ->fetchAll(PDO::FETCH_ASSOC);
                    echo json_encode($response, JSON_UNESCAPED_UNICODE);
                    break;
                default:
                    header("HTTP/1.1 404 Not Found");

                        
        }
    }

    private function auth()
    {
        if(!isset($_SERVER['PHP_AUTH_USER']) || !isset($_SERVER['PHP_AUTH_PW']))
            throw new Exception('Не задан логин/пароль');

        $query = $this ->db
                ->prepare("SELECT * FROM KPKlient WHERE login=:login");
        $query->bindValue(':login', $_SERVER['PHP_AUTH_USER']);
        $query->execute();
        $user = $query->fetch();
        
        if ($user == null)
            throw new Exception('Пользователь не найден');

        if ($user["passWord"] != $_SERVER['PHP_AUTH_PW'])
            throw new Exception('Не верный пароль');

        return $user;
    }

    private function connect()
    {
        // пытаемся подключиться к MySQL серверу
        $this->db = new PDO(
            "mysql:host=kolei.ru;
                port=3306;
                dbname=tnikonova;
                charset=UTF8", 
            "tnikonova", 
            "060803"
        );
    }
}

// создание экземпляра
new ApiServer();

?>