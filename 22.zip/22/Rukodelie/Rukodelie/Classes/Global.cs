﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Rukodelie.Classes
{
    static class Global
    {
        static public int role = 0;
    }
}
