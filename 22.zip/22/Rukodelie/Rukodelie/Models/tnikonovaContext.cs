﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

#nullable disable

namespace Rukodelie.Models
{
    public partial class tnikonovaContext : DbContext
    {
        public tnikonovaContext()
        {
        }

        public tnikonovaContext(DbContextOptions<tnikonovaContext> options)
            : base(options)
        {
        }

        public virtual DbSet<Agent> Agents { get; set; }
        public virtual DbSet<AgentPriorityHistory> AgentPriorityHistories { get; set; }
        public virtual DbSet<AgentType> AgentTypes { get; set; }
        public virtual DbSet<Kpkarty> Kpkarties { get; set; }
        public virtual DbSet<Kpkategorium> Kpkategoria { get; set; }
        public virtual DbSet<Kpklient> Kpklients { get; set; }
        public virtual DbSet<Kprol> Kprols { get; set; }
        public virtual DbSet<Kpstatus> Kpstatuses { get; set; }
        public virtual DbSet<Kptovar> Kptovars { get; set; }
        public virtual DbSet<Kpzakaz> Kpzakazs { get; set; }
        public virtual DbSet<KpzakazTovar> KpzakazTovars { get; set; }
        public virtual DbSet<Material> Materials { get; set; }
        public virtual DbSet<MaterialCountHistory> MaterialCountHistories { get; set; }
        public virtual DbSet<MaterialSupplier> MaterialSuppliers { get; set; }
        public virtual DbSet<MaterialType> MaterialTypes { get; set; }
        public virtual DbSet<Product> Products { get; set; }
        public virtual DbSet<ProductCostHistory> ProductCostHistories { get; set; }
        public virtual DbSet<ProductMaterial> ProductMaterials { get; set; }
        public virtual DbSet<ProductSale> ProductSales { get; set; }
        public virtual DbSet<ProductType> ProductTypes { get; set; }
        public virtual DbSet<Shop> Shops { get; set; }
        public virtual DbSet<Supplier> Suppliers { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see http://go.microsoft.com/fwlink/?LinkId=723263.
                optionsBuilder.UseMySql("server=kolei.ru;database=tnikonova;uid=tnikonova;password=060803", Microsoft.EntityFrameworkCore.ServerVersion.Parse("8.0.36-mysql"));
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.HasCharSet("utf8mb4")
                .UseCollation("utf8mb4_0900_ai_ci");

            modelBuilder.Entity<Agent>(entity =>
            {
                entity.ToTable("Agent");

                entity.UseCollation("utf8mb4_general_ci");

                entity.HasIndex(e => e.AgentTypeId, "FK_Agent_AgentType");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.Address).HasMaxLength(300);

                entity.Property(e => e.AgentTypeId).HasColumnName("AgentTypeID");

                entity.Property(e => e.DirectorName).HasMaxLength(100);

                entity.Property(e => e.Email).HasMaxLength(255);

                entity.Property(e => e.Inn)
                    .IsRequired()
                    .HasMaxLength(12)
                    .HasColumnName("INN");

                entity.Property(e => e.Kpp)
                    .HasMaxLength(9)
                    .HasColumnName("KPP");

                entity.Property(e => e.Logo).HasMaxLength(100);

                entity.Property(e => e.Phone)
                    .IsRequired()
                    .HasMaxLength(20);

                entity.Property(e => e.Title)
                    .IsRequired()
                    .HasMaxLength(150);

                entity.HasOne(d => d.AgentType)
                    .WithMany(p => p.Agents)
                    .HasForeignKey(d => d.AgentTypeId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Agent_AgentType");
            });

            modelBuilder.Entity<AgentPriorityHistory>(entity =>
            {
                entity.ToTable("AgentPriorityHistory");

                entity.UseCollation("utf8mb4_general_ci");

                entity.HasIndex(e => e.AgentId, "FK_AgentPriorityHistory_Agent");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.AgentId).HasColumnName("AgentID");

                entity.Property(e => e.ChangeDate).HasMaxLength(6);

                entity.HasOne(d => d.Agent)
                    .WithMany(p => p.AgentPriorityHistories)
                    .HasForeignKey(d => d.AgentId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_AgentPriorityHistory_Agent");
            });

            modelBuilder.Entity<AgentType>(entity =>
            {
                entity.ToTable("AgentType");

                entity.UseCollation("utf8mb4_general_ci");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.Image).HasMaxLength(100);

                entity.Property(e => e.Title)
                    .IsRequired()
                    .HasMaxLength(50);
            });

            modelBuilder.Entity<Kpkarty>(entity =>
            {
                entity.ToTable("KPKarty");

                entity.UseCollation("utf8mb4_general_ci");

                entity.HasIndex(e => e.KlientId, "FK_KPKatry_KPKlient_idx");

                entity.Property(e => e.Id).HasColumnName("id");

                entity.Property(e => e.KlientId).HasColumnName("klientId");

                entity.Property(e => e.NomerKarty)
                    .IsRequired()
                    .HasMaxLength(20)
                    .HasColumnName("nomerKarty");

                entity.Property(e => e.SrokDeistviya)
                    .IsRequired()
                    .HasMaxLength(5)
                    .HasColumnName("srokDeistviya");

                entity.Property(e => e.Vladelets)
                    .IsRequired()
                    .HasMaxLength(100)
                    .HasColumnName("vladelets");

                entity.HasOne(d => d.Klient)
                    .WithMany(p => p.Kpkarties)
                    .HasForeignKey(d => d.KlientId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_KPKatry_KPKlient");
            });

            modelBuilder.Entity<Kpkategorium>(entity =>
            {
                entity.ToTable("KPKategoria");

                entity.UseCollation("utf8mb4_general_ci");

                entity.Property(e => e.Id).HasColumnName("id");

                entity.Property(e => e.Nazvanie)
                    .IsRequired()
                    .HasMaxLength(100)
                    .HasColumnName("nazvanie");
            });

            modelBuilder.Entity<Kpklient>(entity =>
            {
                entity.ToTable("KPKlient");

                entity.UseCollation("utf8mb4_general_ci");

                entity.HasIndex(e => e.RolId, "FK_KPKlient_KPRol_idx");

                entity.HasIndex(e => e.PassWord, "passWord_UNIQUE")
                    .IsUnique();

                entity.HasIndex(e => e.Login, "telefon_UNIQUE")
                    .IsUnique();

                entity.Property(e => e.Id).HasColumnName("id");

                entity.Property(e => e.DenRozhdeniya)
                    .HasColumnType("date")
                    .HasColumnName("denRozhdeniya");

                entity.Property(e => e.Familiya)
                    .IsRequired()
                    .HasMaxLength(30)
                    .HasColumnName("familiya");

                entity.Property(e => e.Imya)
                    .IsRequired()
                    .HasMaxLength(30)
                    .HasColumnName("imya");

                entity.Property(e => e.Login)
                    .IsRequired()
                    .HasMaxLength(11)
                    .HasColumnName("login");

                entity.Property(e => e.Otchestvo)
                    .HasMaxLength(30)
                    .HasColumnName("otchestvo");

                entity.Property(e => e.PassWord)
                    .IsRequired()
                    .HasMaxLength(30)
                    .HasColumnName("passWord");

                entity.Property(e => e.RolId).HasColumnName("rolId");

                entity.HasOne(d => d.Rol)
                    .WithMany(p => p.Kpklients)
                    .HasForeignKey(d => d.RolId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_KPKlient_KPRol");
            });

            modelBuilder.Entity<Kprol>(entity =>
            {
                entity.ToTable("KPRol");

                entity.Property(e => e.Id).HasColumnName("id");

                entity.Property(e => e.Nazvanie)
                    .IsRequired()
                    .HasMaxLength(45)
                    .HasColumnName("nazvanie");
            });

            modelBuilder.Entity<Kpstatus>(entity =>
            {
                entity.ToTable("KPStatus");

                entity.UseCollation("utf8mb4_general_ci");

                entity.Property(e => e.Id).HasColumnName("id");

                entity.Property(e => e.Status)
                    .IsRequired()
                    .HasMaxLength(20)
                    .HasColumnName("status");
            });

            modelBuilder.Entity<Kptovar>(entity =>
            {
                entity.ToTable("KPTovar");

                entity.UseCollation("utf8mb4_general_ci");

                entity.HasIndex(e => e.KategoriaId, "kategoriaId_idx");

                entity.Property(e => e.Id).HasColumnName("id");

                entity.Property(e => e.Image)
                    .HasMaxLength(100)
                    .HasColumnName("image");

                entity.Property(e => e.KategoriaId).HasColumnName("kategoriaId");

                entity.Property(e => e.Nazvanie)
                    .IsRequired()
                    .HasMaxLength(255)
                    .HasColumnName("nazvanie");

                entity.Property(e => e.Skidka).HasColumnName("skidka");

                entity.Property(e => e.Tsena).HasColumnName("tsena");

                entity.HasOne(d => d.Kategoria)
                    .WithMany(p => p.Kptovars)
                    .HasForeignKey(d => d.KategoriaId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_KPTovar_KPKategoria");
            });

            modelBuilder.Entity<Kpzakaz>(entity =>
            {
                entity.ToTable("KPZakaz");

                entity.UseCollation("utf8mb4_general_ci");

                entity.HasIndex(e => e.KlientId, "FK_KPZakaz_KPKlient_idx");

                entity.HasIndex(e => e.StatusId, "FK_KPZakaz_KPStatus_idx");

                entity.Property(e => e.Id).HasColumnName("id");

                entity.Property(e => e.AdresKlient)
                    .IsRequired()
                    .HasMaxLength(255)
                    .HasColumnName("adresKlient");

                entity.Property(e => e.DataDostavki)
                    .HasColumnType("date")
                    .HasColumnName("dataDostavki");

                entity.Property(e => e.DataOplaty)
                    .HasColumnType("date")
                    .HasColumnName("dataOplaty");

                entity.Property(e => e.DataZakaza)
                    .HasColumnType("date")
                    .HasColumnName("dataZakaza");

                entity.Property(e => e.KlientId).HasColumnName("klientId");

                entity.Property(e => e.StatusId).HasColumnName("statusId");

                entity.HasOne(d => d.Klient)
                    .WithMany(p => p.Kpzakazs)
                    .HasForeignKey(d => d.KlientId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_KPZakaz_KPKlient");

                entity.HasOne(d => d.Status)
                    .WithMany(p => p.Kpzakazs)
                    .HasForeignKey(d => d.StatusId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_KPZakaz_KPStatus");
            });

            modelBuilder.Entity<KpzakazTovar>(entity =>
            {
                entity.ToTable("KPZakazTovar");

                entity.UseCollation("utf8mb4_general_ci");

                entity.HasIndex(e => e.TovarId, "FK_KPZakazTovar_KPTovar_idx");

                entity.HasIndex(e => e.ZakazId, "FK_KPZakazTovar_KPZakaz_idx");

                entity.Property(e => e.Id).HasColumnName("id");

                entity.Property(e => e.Kolichestvo).HasColumnName("kolichestvo");

                entity.Property(e => e.Stoimost).HasColumnName("stoimost");

                entity.Property(e => e.TovarId).HasColumnName("tovarId");

                entity.Property(e => e.ZakazId).HasColumnName("zakazId");

                entity.HasOne(d => d.Tovar)
                    .WithMany(p => p.KpzakazTovars)
                    .HasForeignKey(d => d.TovarId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_KPZakazTovar_KPTovar");

                entity.HasOne(d => d.Zakaz)
                    .WithMany(p => p.KpzakazTovars)
                    .HasForeignKey(d => d.ZakazId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_KPZakazTovar_KPZakaz");
            });

            modelBuilder.Entity<Material>(entity =>
            {
                entity.ToTable("Material");

                entity.UseCollation("utf8mb4_general_ci");

                entity.HasIndex(e => e.MaterialTypeId, "FK_Material_MaterialType");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.Cost).HasPrecision(10, 2);

                entity.Property(e => e.Image).HasMaxLength(100);

                entity.Property(e => e.MaterialTypeId).HasColumnName("MaterialTypeID");

                entity.Property(e => e.Title)
                    .IsRequired()
                    .HasMaxLength(100);

                entity.Property(e => e.Unit)
                    .IsRequired()
                    .HasMaxLength(10);

                entity.HasOne(d => d.MaterialType)
                    .WithMany(p => p.Materials)
                    .HasForeignKey(d => d.MaterialTypeId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Material_MaterialType");
            });

            modelBuilder.Entity<MaterialCountHistory>(entity =>
            {
                entity.ToTable("MaterialCountHistory");

                entity.UseCollation("utf8mb4_general_ci");

                entity.HasIndex(e => e.MaterialId, "FK_MaterialCountHistory_Material");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.ChangeDate).HasMaxLength(6);

                entity.Property(e => e.MaterialId).HasColumnName("MaterialID");

                entity.HasOne(d => d.Material)
                    .WithMany(p => p.MaterialCountHistories)
                    .HasForeignKey(d => d.MaterialId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_MaterialCountHistory_Material");
            });

            modelBuilder.Entity<MaterialSupplier>(entity =>
            {
                entity.HasKey(e => new { e.MaterialId, e.SupplierId })
                    .HasName("PRIMARY")
                    .HasAnnotation("MySql:IndexPrefixLength", new[] { 0, 0 });

                entity.ToTable("MaterialSupplier");

                entity.UseCollation("utf8mb4_general_ci");

                entity.HasIndex(e => e.SupplierId, "FK_MaterialSupplier_Supplier");

                entity.Property(e => e.MaterialId).HasColumnName("MaterialID");

                entity.Property(e => e.SupplierId).HasColumnName("SupplierID");

                entity.HasOne(d => d.Material)
                    .WithMany(p => p.MaterialSuppliers)
                    .HasForeignKey(d => d.MaterialId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_MaterialSupplier_Material");

                entity.HasOne(d => d.Supplier)
                    .WithMany(p => p.MaterialSuppliers)
                    .HasForeignKey(d => d.SupplierId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_MaterialSupplier_Supplier");
            });

            modelBuilder.Entity<MaterialType>(entity =>
            {
                entity.ToTable("MaterialType");

                entity.UseCollation("utf8mb4_general_ci");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.Title)
                    .IsRequired()
                    .HasMaxLength(50);
            });

            modelBuilder.Entity<Product>(entity =>
            {
                entity.ToTable("Product");

                entity.UseCollation("utf8mb4_general_ci");

                entity.HasIndex(e => e.ProductTypeId, "FK_Product_ProductType");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.ArticleNumber)
                    .IsRequired()
                    .HasMaxLength(10);

                entity.Property(e => e.Image).HasMaxLength(100);

                entity.Property(e => e.MinCostForAgent).HasPrecision(10, 2);

                entity.Property(e => e.ProductTypeId).HasColumnName("ProductTypeID");

                entity.Property(e => e.Title)
                    .IsRequired()
                    .HasMaxLength(100);

                entity.HasOne(d => d.ProductType)
                    .WithMany(p => p.Products)
                    .HasForeignKey(d => d.ProductTypeId)
                    .HasConstraintName("FK_Product_ProductType");
            });

            modelBuilder.Entity<ProductCostHistory>(entity =>
            {
                entity.ToTable("ProductCostHistory");

                entity.UseCollation("utf8mb4_general_ci");

                entity.HasIndex(e => e.ProductId, "FK_ProductCostHistory_Product");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.ChangeDate).HasMaxLength(6);

                entity.Property(e => e.CostValue).HasPrecision(10, 2);

                entity.Property(e => e.ProductId).HasColumnName("ProductID");

                entity.HasOne(d => d.Product)
                    .WithMany(p => p.ProductCostHistories)
                    .HasForeignKey(d => d.ProductId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_ProductCostHistory_Product");
            });

            modelBuilder.Entity<ProductMaterial>(entity =>
            {
                entity.HasKey(e => new { e.ProductId, e.MaterialId })
                    .HasName("PRIMARY")
                    .HasAnnotation("MySql:IndexPrefixLength", new[] { 0, 0 });

                entity.ToTable("ProductMaterial");

                entity.UseCollation("utf8mb4_general_ci");

                entity.HasIndex(e => e.MaterialId, "FK_ProductMaterial_Material");

                entity.Property(e => e.ProductId).HasColumnName("ProductID");

                entity.Property(e => e.MaterialId).HasColumnName("MaterialID");

                entity.HasOne(d => d.Material)
                    .WithMany(p => p.ProductMaterials)
                    .HasForeignKey(d => d.MaterialId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_ProductMaterial_Material");

                entity.HasOne(d => d.Product)
                    .WithMany(p => p.ProductMaterials)
                    .HasForeignKey(d => d.ProductId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_ProductMaterial_Product");
            });

            modelBuilder.Entity<ProductSale>(entity =>
            {
                entity.ToTable("ProductSale");

                entity.UseCollation("utf8mb4_general_ci");

                entity.HasIndex(e => e.AgentId, "FK_ProductSale_Agent");

                entity.HasIndex(e => e.ProductId, "FK_ProductSale_Product");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.AgentId).HasColumnName("AgentID");

                entity.Property(e => e.ProductId).HasColumnName("ProductID");

                entity.Property(e => e.SaleDate).HasColumnType("date");

                entity.HasOne(d => d.Agent)
                    .WithMany(p => p.ProductSales)
                    .HasForeignKey(d => d.AgentId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_ProductSale_Agent");

                entity.HasOne(d => d.Product)
                    .WithMany(p => p.ProductSales)
                    .HasForeignKey(d => d.ProductId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_ProductSale_Product");
            });

            modelBuilder.Entity<ProductType>(entity =>
            {
                entity.ToTable("ProductType");

                entity.UseCollation("utf8mb4_general_ci");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.Title)
                    .IsRequired()
                    .HasMaxLength(50);
            });

            modelBuilder.Entity<Shop>(entity =>
            {
                entity.ToTable("Shop");

                entity.UseCollation("utf8mb4_general_ci");

                entity.HasIndex(e => e.AgentId, "FK_Shop_Agent");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.Address).HasMaxLength(300);

                entity.Property(e => e.AgentId).HasColumnName("AgentID");

                entity.Property(e => e.Title)
                    .IsRequired()
                    .HasMaxLength(150);

                entity.HasOne(d => d.Agent)
                    .WithMany(p => p.Shops)
                    .HasForeignKey(d => d.AgentId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Shop_Agent");
            });

            modelBuilder.Entity<Supplier>(entity =>
            {
                entity.ToTable("Supplier");

                entity.UseCollation("utf8mb4_general_ci");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.Inn)
                    .IsRequired()
                    .HasMaxLength(12)
                    .HasColumnName("INN");

                entity.Property(e => e.StartDate).HasColumnType("date");

                entity.Property(e => e.SupplierType).HasMaxLength(20);

                entity.Property(e => e.Title)
                    .IsRequired()
                    .HasMaxLength(150);
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
