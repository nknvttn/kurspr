﻿using Microsoft.EntityFrameworkCore;
using Rukodelie.Classes;
using Rukodelie.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Rukodelie.Windows
{
    /// <summary>
    /// Логика взаимодействия для ProductWindow.xaml
    /// </summary>
    public partial class ProductWindow : Window, INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;

        public List<Kpkategorium> TovarTypeList { get; set; }



        public string[] SortList { get; set; } = {
            "Без сортировки",
            "Название по убыванию",
            "Название по возрастанию",
            "Цена по убыванию",
            "Цена по возрастанию"};

        public ProductWindow()
        {
            InitializeComponent();
            DataContext = this;
            using (var context = new tnikonovaContext())
            {
                TovarList = context.Kptovars.ToList();

                TovarTypeList = context.Kpkategoria.ToList();
                TovarTypeList.Insert(0, new Kpkategorium { Nazvanie = "Все категории товаров" });

            }

           
        }

        private IEnumerable<Kptovar> _tovarList;

        // тут мы храним номер текущей страницы
        private int _currentPage = 0;
        // при смене текущей страницы мы должны перерисовать список (вспоминайте про INotifyPropertyChanged)
        private int currentPage
        {
            get
            {
                return _currentPage;
            }
            set
            {
                _currentPage = value;
                Invalidate();
            }
        }

        //и реализуем геттер и сеттер списка продукции
        public IEnumerable<Kptovar> TovarList
        {
            get
            {
                var Result = _tovarList;

                if (TovarTypeFilterId > 0)
                    Result = Result.Where(
                        p => p.KategoriaId == TovarTypeFilterId);

                if (SearchFilter != "")
                    Result = Result.Where(
                        p => p.Nazvanie.IndexOf(SearchFilter, StringComparison.OrdinalIgnoreCase) >= 0
                            
                    );

                switch (SortType)
                {
                    // сортировка по названию продукции
                    case 1:
                        Result = Result.OrderBy(p => p.Nazvanie);
                        break;
                    case 2:
                        Result = Result.OrderByDescending(p => p.Nazvanie);
                        break;
                    case 3:
                        Result = Result.OrderBy(p => p.Tsena);
                        break;
                    case 4:
                        Result = Result.OrderByDescending(p => p.Tsena);
                        break;
                        // остальные сортировки реализуйте сами
                }


                return Result;
            }
            set
            {
                _tovarList = value;
                Invalidate();
            }
        }


        private void Invalidate(string ComponentName = "TovarList")
        {
            if (PropertyChanged != null)
                PropertyChanged(this, new PropertyChangedEventArgs(ComponentName));
        }

        

        private int SortType = 0;

        private void SortTypeComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            SortType = SortTypeComboBox.SelectedIndex;
            Invalidate();
        }

        private int TovarTypeFilterId = 0;
        private void TovarTypeFilter_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

            // запоминаем ID выбранного типа
            TovarTypeFilterId = (TovarTypeFilter.SelectedItem as Kpkategorium).Id;
            Invalidate();

        }

        private string SearchFilter = "";
        private void SearchFilterTextBox_KeyUp(object sender, KeyEventArgs e)
        {
            SearchFilter = SearchFilterTextBox.Text;
            Invalidate();
        }

        private void ExitButton_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();
        }
        private void TovarListView_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            // в создаваемое окно передаем выбранный продукт
            var NewEditWindow = new EditTovarWindow(TovarListView.SelectedItem as Kptovar);
            if ((bool)NewEditWindow.ShowDialog())
            {
                // при успешном сохранении продукта перечитываем список продукции
                using (var context = new tnikonovaContext())
                {
                    TovarList = context.Kptovars
                        .Include(tovar => tovar.Kategoria)
                        .ToList();
                }
            }
        }

        private void AddTovarButton_Click(object sender, RoutedEventArgs e)
        {
            var NewEditWindow = new EditTovarWindow(new Kptovar());

            if ((bool)NewEditWindow.ShowDialog())
            {
                // при успешном сохранении продукта перечитываем список продукции
                using (var context = new tnikonovaContext())

                    TovarList = context.Kptovars.ToList();
            }
        }

        public string AdminEditVisible
        {
            get
            {
                if (Global.role == 1) return "Visible";
                return "Collapsed";
            }
        }

    }
}
