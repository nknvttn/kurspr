﻿using Rukodelie.Classes;
using Rukodelie.Models;
using Rukodelie.Windows;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
namespace Rukodelie
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        
        public IEnumerable<Kpklient> KlientList { get; set; }

        bool isLogin = false;


        public MainWindow()
        {
            InitializeComponent();
            DataContext = this;
            using (var context = new tnikonovaContext())
            {
                KlientList = context.Kpklients.ToList();
            }
        }

        private void AuthButton_Click(object sender, RoutedEventArgs e)
        {
            
            string login = loginTextBox.Text;
            string password = passwordTextBox.Text;

            try
            {

                if (loginTextBox.Text == null || passwordTextBox.Text == null)
                {
                    MessageBox.Show("Заполните логин и пароль!");
                }
                else
                {
                    Kpklient KPklient = KlientList.Where((u) => u.Login == login && u.PassWord == password).Single();

                    if (KPklient == null) return;

                    Global.role = KPklient.RolId;

                    if (KPklient != null && KPklient.RolId == 1)
                    {
                        this.Hide();
                        ProductWindow TovarWindow = new ProductWindow();
                        TovarWindow.Show();
                    }


                    if (KPklient != null && KPklient.RolId == 2)
                    {
                        this.Hide();
                        ProductWindow TovarWindow = new ProductWindow();
                        TovarWindow.Show();
                    }


                }

            }
            catch
            {
                MessageBox.Show("Ошибка! Попробуйте снова!", $"Неверный логин или пароль!");
            }
        }
        
    }
}
