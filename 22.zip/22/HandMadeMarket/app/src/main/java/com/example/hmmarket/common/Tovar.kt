package com.example.hmmarket.common

data class Tovar(
    val id: Int,
    val nazvanie: String,
    val tsena: Double,
    val image: String
)
