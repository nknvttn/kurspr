package com.example.hmmarket.common

import android.app.Application

class MyApp: Application() {
    var token = ""
    var login = ""
    var password = ""

}