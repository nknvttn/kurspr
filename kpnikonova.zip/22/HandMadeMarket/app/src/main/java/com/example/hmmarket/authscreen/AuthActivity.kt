package com.example.hmmarket.authscreen

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import androidx.appcompat.app.AlertDialog
import com.example.hmmarket.R
import com.example.hmmarket.catalogscreen.CatalogActivity
import com.example.hmmarket.common.Http
import com.example.hmmarket.common.MyApp
import com.example.hmmarket.registrscreen.RegistrActivity
import okhttp3.Response
import org.json.JSONObject

class AuthActivity : AppCompatActivity() {

    lateinit var loginEditText: EditText
    lateinit var passwordEditText: EditText
    lateinit var enterButton: Button
    private lateinit var app: MyApp

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_auth)

        supportActionBar?.hide()

        app = applicationContext as MyApp

        loginEditText = findViewById(R.id.loginEditText)
        passwordEditText = findViewById(R.id.passwordEditText)
        enterButton = findViewById(R.id.enterButton)

        enterButton.setOnClickListener{
            try {
                if (loginEditText.text.isEmpty())
                    throw Exception("Не заполнен логин пользователя")
                if (passwordEditText.text.isEmpty())
                    throw Exception("Не заполнен пароль пользователя")

                val login = loginEditText.text.toString()
                val password = passwordEditText.text.toString()

                Http.call(
                    Http.buildRequest(
                        "http://192.168.3.112:8080/login",
                        JSONObject()
                            .put("login", login)
                            .put("password", password)
                            .toString()
                    ),
                    registerCallback

                )


            } catch (e: Exception) {
                showAlert(e.message)
            }
        }
    }

    private val registerCallback: (response: Response?, error: Exception?)->Unit =
        { response, error ->
            try {
                // если в запросе получено исключение, то "выбрасываем" его
                if (error != null) throw error

                // если ответ получен, но код не 200, то тоже "выбрасываем" исключение
                if (!response!!.isSuccessful) throw Exception(response.message)

                val jsonResp = JSONObject(response.body!!.string())

                runOnUiThread {
                    // тут можно переходить на следующее окно
                    startActivity(
                        Intent(this, CatalogActivity::class.java)
                    )
                }


            } catch (e: Exception) {
                // любую ошибку показываем на экране
                showAlert(e.message)
            }
        }

    private fun showAlert(message: String?) {
        runOnUiThread {
            AlertDialog.Builder(this)
                .setTitle("Ошибка")
                .setMessage(message)
                .setPositiveButton("OK", null)
                .create()
                .show()
        }
    }

    fun RegistrEnterClick(view: View) {
        startActivity(
            Intent(this, RegistrActivity::class.java)
        )
    }

    fun Catalog(view: View) {
        startActivity(
            Intent(this, CatalogActivity::class.java)
        )
    }
}