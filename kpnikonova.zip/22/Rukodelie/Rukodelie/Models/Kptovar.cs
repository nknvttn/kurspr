﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Rukodelie.Models
{
    public partial class Kptovar
    {
        public Kptovar()
        {
            KpzakazTovars = new HashSet<KpzakazTovar>();
        }

        public int Id { get; set; }
        public string Nazvanie { get; set; }
        public double Tsena { get; set; }
        public int? Skidka { get; set; }
        public int KategoriaId { get; set; }
        public string Image { get; set; }

        public virtual Kpkategorium Kategoria { get; set; }
        public virtual ICollection<KpzakazTovar> KpzakazTovars { get; set; }
    }
}
