﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Rukodelie.Models
{
    public partial class Kpkategorium
    {
        public Kpkategorium()
        {
            Kptovars = new HashSet<Kptovar>();
        }

        public int Id { get; set; }
        public string Nazvanie { get; set; }

        public virtual ICollection<Kptovar> Kptovars { get; set; }
    }
}
