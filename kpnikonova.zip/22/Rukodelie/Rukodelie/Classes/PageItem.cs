﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Rukodelie.Classes
{
    public class PageItem
    {
        public string label { get; set; }
    }
}
