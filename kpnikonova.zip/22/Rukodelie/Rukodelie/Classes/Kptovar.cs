﻿using Rukodelie.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Rukodelie.Models
{
    public partial class Kptovar
    {
        public Uri ImagePreview
        {
            get
            {
                var imageName = Environment.CurrentDirectory + (Image ?? "");
                return System.IO.File.Exists(imageName) ? new Uri(imageName) : null;
            }
        }


        public string BackgroundColor
        {
            get
            {

                using (var context = new tnikonovaContext())
                {
                    //ищем количество продаж, совершённых позже указанной даты
                    //фильтруя продажи по Id продукта
                    var saleTovar = context.Kptovars
                        .Where(st => st.Skidka == this.Skidka)
                        .Count(st => st.Skidka > 0);

                    //возвращаем цвет, в зависимости от количества продаж
                    if (saleTovar > 0) return "#aac5ec";
                    return "#fff";
                }
            }
        }
    }
}
