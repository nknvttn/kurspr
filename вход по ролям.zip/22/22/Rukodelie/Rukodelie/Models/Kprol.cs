﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Rukodelie.Models
{
    public partial class Kprol
    {
        public Kprol()
        {
            Kpklients = new HashSet<Kpklient>();
        }

        public int Id { get; set; }
        public string Nazvanie { get; set; }

        public virtual ICollection<Kpklient> Kpklients { get; set; }
    }
}
