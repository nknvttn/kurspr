CREATE TABLE IF NOT EXISTS `KPKategoria`(
	`id` int(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
	`nazvanie` varchar(30) NOT NULL
);

CREATE TABLE IF NOT EXISTS `KPKarty`(
	`id` int(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
	CONSTRAINT `klientId` FOREIGN KEY (`KPKlient_id`) REFERENCES `KPKlient`(`id`),
	`vladelets` varchar(100) NOT NULL,
	`nomerKarty` varchar(20) NOT NULL,
	`srokDeistviya` varchar(5) NOT NULL
);

CREATE TABLE IF NOT EXISTS `KPStatus`(
	`id` int(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
	`status` varchar(20) NOT NULL
);

CREATE TABLE IF NOT EXISTS `KPKlient`(
	`id` int(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
	`imya` varchar(30) NOT NULL,
	`familiya` varchar(30) NOT NULL,
	`otchestvo` varchar(30) DEFAULT NULL,
	`login` varchar(12) NOT NULL,
	`denRozhdeniya` DATE NOT NULL
);

CREATE TABLE IF NOT EXISTS `KPKarty`(
	`id` int(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
	CONSTRAINT `klientId` FOREIGN KEY (`KPKlient_id`) REFERENCES `KPKlient`(`id`),
	CONSTRAINT `statusId` FOREIGN KEY (`KPStatus_id`) REFERENCES `KPStatus`(`id`),
	`dataZakaza` DATE NOT NULL,
	`adresKlient` varchar(225) NOT NULL,
	`dataDostavki` DATE NOT NULL,
	`dataOplata` DATE NOT NULL
);

CREATE TABLE IF NOT EXISTS `KPTovar`(
	`id` int(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
	`nazvanie` varchar(100) NOT NULL,
	`tsena` FLOAT NOT NULL,
	`skidka` int(11) DEFAULT NULL,
	CONSTRAINT `kategoriaId` FOREIGN KEY (`kategoria_id`) REFERENCES `KPKategoria`(`id`)
);

CREATE TABLE IF NOT EXISTS `KPZakazTovar`(
	`id` int(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
	CONSTRAINT `zakazId` FOREIGN KEY (`KPZakaz_id`) REFERENCES `KPZakaz`(`id`),
	CONSTRAINT `tovarId` FOREIGN KEY (`KPTovar_id`) REFERENCES `KPTovar`(`id`),
	`kolichestvo` int(11) NOT NULL,
	`stoimost` FLOAT NOT NULL
);