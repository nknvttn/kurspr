package com.example.hmmarket.catalogscreen

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import androidx.appcompat.app.AlertDialog
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.hmmarket.R
import com.example.hmmarket.adapter.TovarAdapter
import com.example.hmmarket.common.Http
import com.example.hmmarket.common.MyApp
import com.example.hmmarket.common.Tovar
import org.json.JSONArray

class CatalogActivity : AppCompatActivity() {

    private lateinit var app: MyApp
    private val tovarList = ArrayList<Tovar>()
    private lateinit var tovarRecyclerView: RecyclerView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_catalog)

        supportActionBar?.hide()

        app = applicationContext as MyApp

        tovarRecyclerView = findViewById(R.id.tovarRecyclerView)

// назначаем менеджер разметки
        tovarRecyclerView.layoutManager = LinearLayoutManager(
            this,
            RecyclerView.VERTICAL,
            false)

// создаем адаптер
        val tovarAdapter = TovarAdapter(
            tovarList,
            this)

// при клике на элемент списка показать подробную информацию (сделайте сами)
        tovarAdapter.setItemClickListener { tovar ->
            Log.d("KEILOG", "Click on Weather item")
        }

        tovarRecyclerView.adapter = tovarAdapter

        Http.call(
            "http://192.168.3.112:8080/Tovar",
        )
        { response, error ->
            try {
                // если в запросе получено исключение, то "выбрасываем" его
                if (error != null) throw error

                // если ответ получен, но код не 200, то тоже "выбрасываем" исключение
                if (!response!!.isSuccessful) throw Exception(response.message)

                tovarList.clear()

                val list = JSONArray(response.body!!.string())
//                if(!json.has("notice"))

                // перебираем json массив
                for (i in 0 until list.length()) {
                    val item = list.getJSONObject(i)

                    // добавляем в список новый элемент
                    tovarList.add(
                        Tovar(
                            item.getInt("id"),
                            item.getString("nazvanie"),
                            item.getDouble("tsena"),
                            item.getString("image")
                        )
                    )
                }


                runOnUiThread {
                    // уведомляем визуальный элемент, что данные изменились
                    tovarRecyclerView.adapter?.notifyDataSetChanged()
                }
            } catch (e: Exception) {
                // любую ошибку показываем на экране
                runOnUiThread {
                    AlertDialog.Builder(this)
                        .setTitle("Ошибка")
                        .setMessage(e.message)
                        .setPositiveButton("OK", null)
                        .create()
                        .show()
                }
            }

        }

    }
}