package com.example.hmmarket.adapter

import android.app.Activity
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.hmmarket.R
import com.example.hmmarket.common.Tovar
import okhttp3.*
import okio.IOException
import java.util.ArrayList

class TovarAdapter (
    private val values: ArrayList<Tovar>,
    private val activity: Activity
): RecyclerView.Adapter<TovarAdapter.ViewHolder>()
{

    private var itemClickListener: ((Tovar) -> Unit)? = null

    fun setItemClickListener(itemClickListener: (Tovar) -> Unit) {
        this.itemClickListener = itemClickListener
    }

    private val client = OkHttpClient()

    private fun loadImage(icoUrl: String, callback: (result: Bitmap?)->Unit) {
        val request = Request.Builder()
            .url(icoUrl)
            .build()

        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                e.printStackTrace()
            }

            override fun onResponse(call: Call, response: Response) {
                response.use {
                    if (!response.isSuccessful)
                        throw IOException("Unexpected code $response")

                    // тело запроса считваем как поток байт и передаем его в построитель изображений (BitmapFactory)
                    val bitmap = BitmapFactory
                        .decodeStream(
                            response.body!!.byteStream()
                        )

                    callback.invoke(bitmap)
                }
            }
        })
    }

    // Метод onCreateViewHolder вызывается при создании визуального элемента
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        // грузим layout, который содержит вёрстку элемента списка (нарисуйте сами)
        val itemView = LayoutInflater
            .from(parent.context)
            .inflate(
                R.layout.tovar_item,
                parent,
                false)

        // создаем на его основе ViewHolder
        return ViewHolder(itemView)
    }

    override fun getItemCount(): Int = values.size

    // заполняет визуальный элемент данными
    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.textViewTovarNazvanie.text = values[position].nazvanie
        holder.textViewTovarTsena.text = values[position].tsena.toString()
        // onIconLoad.invoke(holder.iconImageView, values[position].weatherIcon)
        holder.imageViewTovar.setOnClickListener{
            itemClickListener?.invoke(values[position])
        }

        if (values[position].image != "") {
            val fileName = values[position].image
            loadImage("http://192.168.3.112:8080${fileName}") { bitmap ->
                activity.runOnUiThread {
                    try {
                        holder.imageViewTovar.setImageBitmap(bitmap)
                    } catch (e: Exception) {

                    }
                }

            }
        }
    }

    //Реализация класса ViewHolder, хранящего ссылки на виджеты.
    class ViewHolder(itemView: View): RecyclerView.ViewHolder(itemView){
        var imageViewTovar: ImageView = itemView.findViewById(R.id.imageViewTovar)
        var textViewTovarNazvanie: TextView = itemView.findViewById(R.id.textViewTovarNazvanie)
        var textViewTovarTsena: TextView = itemView.findViewById(R.id.textViewTovarTsena)
    }
}